const { deleteUserData } = require("./deleteUserData");

module.exports = {
    deleteUserData
};