/**
 * @file checkUserAuthenticate.js
 * @summary check user password validation and create Jwt token
 */


const bcrypt = require("bcrypt");
const { readFile} = require("fs");
const { join} = require("path");
const { throwUnAuthenticatedError } = require(__basedir+"/errors");
const {createToken} = require(__basedir+"/middlewares");

function checkUserAuthenticate(userObj){
    const filePath = join(__dirname,"/../../../../users/users.json");
    return new Promise((resolve,reject)=>{
        readFile(filePath,'utf-8',(err,data)=>{
            if(err) return new Error("Error in reading the file");
            const userDataObject = JSON.parse(data);
            //console.log(userDataObject);
            let userEmail = userDataObject.find(item => item.email === userObj.email);
            if(userEmail){
                let userPassword = userEmail.password;
                bcrypt.compare(userObj.password,userPassword,(err,result)=>{
                    if(err){
                        throwUnAuthenticatedError("Auth failed");
                    }
                    if(result){
                        const token =createToken(userObj);
                        resolve(token);
                        //console.log(token);
                        console.log("Login Successful");
                    }else{
                       throwUnAuthenticatedError("Invalid username or passoword");
                   }
                }); 
            }else{
                throwUnAuthenticatedError("Invalid username or passoword");
            }
        });
    });
}


 module.exports= {
     checkUserAuthenticate
 }