const { checkUserAuthenticate } = require("./checkUserAuthenticate");

module.exports = {
    checkUserAuthenticate
};