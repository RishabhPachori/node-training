/**
 * @file updateUserData.js
 * @summary updates user data by Id
 */

const { throwUnAuthorizedError } = require(__basedir+"/errors");
const { readFile,writeFile} = require("fs");
const bcrypt = require("bcrypt");
const { join} = require("path");

/**
 * Method for updates user data by Id
 * @param {object} payload payload payload is received when user is authenticated.
 * @param {number} userId user Id
 * @param {object} updatedData updated Data
 */
async function updateUserData(payload,userId,updatedData) {
    updatedData.password = await bcrypt.hash(updatedData.password,10);
    return new Promise((resolve,reject)=>{
        let filePath = join(__dirname,"/../../../../users/users.json");
        readFile(filePath,'utf-8',(err,data)=>{
            if(err) return new Error("Error in reading the file");
            const usersObject = JSON.parse(data);
            let findRole = usersObject.find(item => item.role === payload.role);
            let findId = usersObject.find(item => item.id === payload.id);
            if(findRole.role === "admin"){
                let findUserObject = usersObject.findIndex(item => item.id == userId);
                usersObject.splice(findUserObject,1,updatedData);
                const stringData = JSON.stringify(usersObject);
                writeFile(filePath,stringData,err=>{
                    if(err) return new Error("Error in writting the file");
                });
                resolve(usersObject);
            }else if (findRole.role === "user" && findId.id == userId ){
                let findUserObject = usersObject.findIndex(item => item.id == userId);
                usersObject.splice(findUserObject,1,updatedData);
                const stringData = JSON.stringify(usersObject);
                writeFile(filePath,stringData,err=>{
                    if(err) return new Error("Error in writting the file");
                });
                resolve(usersObject);
            }else{
                throwUnAuthorizedError("You Are Not Authorized");
            }
        });
    });
    
}

module.exports = {
    updateUserData
};
