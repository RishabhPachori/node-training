const { updateUserData } = require("./updateUserData");

module.exports = {
    updateUserData
};