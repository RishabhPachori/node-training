/**
 * @file getUserData.js
 * @summary get all  users related information
 */

const { throwUnAuthorizedError } = require(__basedir+"/errors");
const { readFile} = require("fs");
const { join} = require("path");

/**
 * Method for get all the users
 * @param {object} payload payload payload is received when user is authenticated.
 */

function getUserData(payload) {
    return new Promise((resolve,reject)=>{
        let filePath = join(__dirname,"/../../../../users/users.json");
        readFile(filePath,'utf-8',(err,data)=>{
            if(err) return new Error("Error in reading the file");
            const usersObject = JSON.parse(data);
            let findRole = usersObject.find(item => item.role === payload.role);
            //console.log(findRole.role);
            if(findRole.role === "admin"){
                resolve(usersObject);
            }else{
                throwUnAuthorizedError("You Are Not Authorized");
            }
        });
    });
}

module.exports = {
    getUserData
};
