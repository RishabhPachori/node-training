/**
 * @file addUserData.js
 * @summary add user related information
 */


const { writeFile,stat, readFile} = require("fs");
const bcrypt = require("bcrypt");
const { throwBadRequestError } = require(__basedir + "/errors");
const { join } = require("path");



/**
 * method for create or add user information
 * @param {object} userObj user Object
 */



async function addUserData(userObj){
    userObj.password = await bcrypt.hash(userObj.password,10);
    const filePath = join(__dirname,"/../../../../users/users.json");
    let dataObj;
    return new Promise((resolve,reject)=>{
        stat(filePath,(err)=>{
            if(err==null){
                readFile(filePath,'utf-8',(err,data)=>{
                    if(err){
                        throwBadRequestError("Error while reading data in file");
                    }
                    dataObj = JSON.parse(data);
                    let duplicateUserCheck = dataObj.find(item => item.id === userObj.id);
                    if(duplicateUserCheck){
                        throwBadRequestError(`User already exists ${userObj.id}`);
                    }else{
                        dataObj.push(userObj);
                        const stringData = JSON.stringify(dataObj);
                        writeFile(filePath,stringData,err=>{
                            if(err){
                                throwBadRequestError("Error while writting data in file");
                            }
                        });
                    }
                });
                console.log("File exists");
            }else if(err.code === 'ENOENT'){
                dataObj = [userObj];
                const stringData = JSON.stringify(dataObj);
                // file doesn't exist
                writeFile(filePath,stringData,err=>{
                    if(err) return new Error("Error in new file writting");
                });
            }else{
                console.log('Some other error',err.code);
            }
        });
        resolve("data added successfully");
    });

}

module.exports = {
    addUserData
};