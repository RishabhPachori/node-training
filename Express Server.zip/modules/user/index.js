/**
 * @file index.js
 * @summary File contains User Routes 
 */
const { getUsers,addUser,updateUser,deleteuser,userAuthenticate } = require("./controller");
const { authenticateUserWithToken } = require(__basedir+"/middlewares");

module.exports = router => {
    router.get("/users",authenticateUserWithToken,getUsers);
    router.post("/users",addUser);
    router.put("/users/:id",authenticateUserWithToken,updateUser);
    router.delete("/users/:id",authenticateUserWithToken,deleteuser);
    router.post("/login-user",userAuthenticate);
};