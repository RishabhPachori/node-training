/**
 * @file controller.js
 * @summary user Controllers
 * @description It contains controller definition for user entity
 * Each method is responsible to passing data , extracting data , passing to correspond action
 * and send response back to client 
 */
const { getUserData, addUserData, updateUserData, deleteUserData,checkUserAuthenticate } = require("./actions");


/**
 * Controller for get all the users
 * @param {object} req Http req object
 * @param {object} res Http res object
 */
const getUsers = async (req,res) => {
    try {
        const payload=req.user;
        const data = await getUserData(payload);
        return res.status(200).send(data);
    }catch (error) {
        res.status(error.code).send({
            error: error.message
        });
    }
}


/**
 * Controller for add or create users.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const addUser = async (req,res) => {
    try {
        const userObj = req.body;
        const data = await addUserData(userObj);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

/**
 * Controller for updates user related information .
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const updateUser = async (req,res) => {
    try {
        const payload = req.user;
        const userId =req.params.id;
        let updatedData = {};
        updatedData = req.body;
        const data = await updateUserData(payload,userId,updatedData);
        return res.status(200).send(data);
    }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

/**
 * Controller for deletes user related information .
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const deleteuser =  async(req,res) => {
    try {
        const payload = req.user;
        const userId = req.params.id;
        const data = await deleteUserData(payload,userId);
        return res.status(200).send(data);
    }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

/// user Authenticate
const userAuthenticate = async(req,res)=>{
    try {
        const userObj = req.body;
        const data = await checkUserAuthenticate(userObj);
        return res.status(200).send(data);
        }
        catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

module.exports ={
    getUsers,
    addUser,
    updateUser,
    deleteuser,
    userAuthenticate

};