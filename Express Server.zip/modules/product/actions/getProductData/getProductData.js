/**
 * @file getProductData.js
 * @summary get all products related information
 */
const { readFile} = require("fs");
const { throwBadRequestError } = require(__basedir + "/errors");
const { join } = require("path");

/**
 * Method for get all the products
 * @param {object} payload payload payload is received when user is authenticated.
 */

function getProductData(payload) {
    return new Promise((resolve,reject)=>{
        let filePath = join(__dirname,"/../../../../products/products.json");
        if(payload.role === "admin"){
            readFile(filePath,'utf-8',(err,data)=>{
                if(err) return new Error("Error in reading the file");
                resolve(JSON.parse(data));
            });

        }else if(payload.role === "user"){
            readFile(filePath,'utf-8',(err,data)=>{
                if(err) return new Error("Error in reading the file");
                const productData = JSON.parse(data);
                function userFilter(productData){
                    return productData.userId === payload.id;
                }
                const filterData = productData.filter(userFilter);
                resolve(filterData);
            });
        }else{
            throwBadRequestError("cannot find product for this user");
        }
    });
}

module.exports = {
    getProductData
};