const { addProductData } = require("./addProductData");

module.exports = {
    addProductData
};