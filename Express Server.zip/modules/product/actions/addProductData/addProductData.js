/**
 * @file addProductData.js
 * @summary add product related information
 */

const { writeFile,stat, readFile} = require("fs");
const { throwUnAuthorizedError } = require(__basedir + "/errors");
const { join } = require("path");




/**
 * method for create or add product information
 * @param {object} payload payload payload is received when user is authenticated.
 * @param {object} productObj product Object
 */

function addProductData(payload,productObj) {
    const filePath = join(__dirname,"/../../../../products/products.json");
    let dataObj;
    return new Promise((resolve,reject)=>{
        if(payload.role === "user"){
            stat(filePath,(err)=>{
                if(err==null){
                    readFile(filePath,'utf-8',(err,data)=>{
                        if(err){
                            throwBadRequestError("Error while reading data in file");
                        }
                        dataObj = JSON.parse(data);
                        let duplicateProductCheck = dataObj.find(item => item.id === productObj.id);
                        if(duplicateProductCheck){
                            throwBadRequestError(`Product already exists ${productObj.id}`);
                        }else{
                            productObj["userId"]=payload.id;
                            dataObj.push(productObj);
                            const stringData = JSON.stringify(dataObj);
                            writeFile(filePath,stringData,err=>{
                                if(err){
                                    throwBadRequestError("Error while writting data in file");
                                }
                            });
                        }
                    });
                    console.log("File exists");
                }else if(err.code === 'ENOENT'){
                        productObj["userId"]=payload.id;
                        dataObj = [productObj];
                        const stringData = JSON.stringify(dataObj);
                        // file doesn't exist
                        writeFile(filePath,stringData,err=>{
                            if(err) return new Error("Error in new file writting");
                        });
                    }else{
                    console.log('Some other error',err.code);
                }
            });
            resolve("data added successfully");
        }else{
            throwUnAuthorizedError("You are not Authorized");
        }
    });
    
}

module.exports = {
    addProductData
};