/**
 * @file deleteProductData.js
 * @summary delete product related information
 */

const { throwUnAuthorizedError } = require(__basedir+"/errors");
const { readFile,writeFile} = require("fs");
const { join} = require("path");




/**
 * method for delete product related information
 * @param {object} payload payload payload is received when user is authenticated.
 * @param {number} userId req userId
 * @param {number} productId req productId
 */

function deleteProductData(payload,userId,productId) {
    return new Promise((resolve,reject)=>{
        let filePath = join(__dirname,"/../../../../products/products.json");
        readFile(filePath,'utf-8',(err,data)=>{
            if(err) return new Error("Error in reading the file");
            const productData = JSON.parse(data);
            let findProductIndex = productData.findIndex(item => item.userId == userId && item.id == productId);
            if(payload.role === "admin"){
                productData.splice(findProductIndex,1);
                const stringData = JSON.stringify(productData);
                writeFile(filePath,stringData,err=>{
                    if(err) return new Error("Error in writting the file");
                });
                resolve(productData);
            }else if (payload.role === "user" && userId == payload.id){
                productData.splice(findProductIndex,1);
                const stringData = JSON.stringify(productData);
                writeFile(filePath,stringData,err=>{
                    if(err) return new Error("Error in writting the file");
                });
                resolve(productData);
            }else{
                throwUnAuthorizedError("You Are Not Authorized");
            }
        });
    });
}

module.exports = {
    deleteProductData
};