/**
 * @file updateProductData.js
 * @summary updates product data by Id
 */
const { throwUnAuthorizedError } = require(__basedir+"/errors");
const { readFile,writeFile} = require("fs");
const { join} = require("path");
/**
 * Method for updates product data by Id
 * @param {object} payload payload payload is received when user is authenticated.
 * @param {number} userId req userId
 * @param {number} productId req productId
 * @param {Object} updatedData updatedData 
 */


function updateProductData(payload,userId,productId,updatedData){
    return new Promise((resolve,reject)=>{
        let filePath = join(__dirname,"/../../../../products/products.json");
        readFile(filePath,'utf-8',(err,data)=>{
            if(err) return new Error("Error in reading the file");
            const productData = JSON.parse(data);
            let findProductIndex = productData.findIndex(item => item.userId == userId && item.id == productId);
            if(payload.role === "admin"){
                updatedData["userId"]=payload.id;
                productData.splice(findProductIndex,1,updatedData);
                const stringData = JSON.stringify(productData);
                writeFile(filePath,stringData,err=>{
                    if(err) return new Error("Error in writting the file");
                });
                resolve(productData);
            }else if(payload.role === "user" && userId == payload.id){
                updatedData["userId"]=payload.id;
                productData.splice(findProductIndex,1,updatedData);
                const stringData = JSON.stringify(productData);
                writeFile(filePath,stringData,err=>{
                    if(err) return new Error("Error in writting the file");
                });
                resolve(productData);

            }else{
                throwUnAuthorizedError("You Are Not Authorized");
            }
        });
    });
}



module.exports = {
    updateProductData
};