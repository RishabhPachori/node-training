const { getProductData } = require("./getProductData");
const { addProductData } = require("./addProductData");
const { updateProductData } = require("./updateProductData");
const { deleteProductData } = require("./deleteProductData");

module.exports = {
    getProductData,
    addProductData,
    updateProductData,
    deleteProductData
};