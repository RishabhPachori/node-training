/**
 * @file index.js
 * @summary File contains Products Routes 
 */
const { getProducts,addProduct,updateProduct,deleteProduct } = require("./controller");
const { authenticateUserWithToken } = require(__basedir+"/middlewares");

module.exports = router => {
    router.get("/products",authenticateUserWithToken,getProducts);
    router.post("/products",authenticateUserWithToken,addProduct);
    router.put("/products/:id",authenticateUserWithToken,updateProduct);
    router.delete("/products/:id",authenticateUserWithToken,deleteProduct);
};