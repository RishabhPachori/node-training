const { AppError } = require("./appError");
const { log } = require("./logger");

const {
    throwBadRequestError,
    throwNotFoundError,
    throwInternalServerError,
    throwUnAuthenticatedError,
    throwUnAuthorizedError
 } = require("./methods");


 module.exports ={
    AppError,
    log,
    throwBadRequestError,
    throwNotFoundError,
    throwInternalServerError,
    throwUnAuthenticatedError,
    throwUnAuthorizedError
 };