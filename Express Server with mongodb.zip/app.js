/**
 * @file app.js
 * @summary Create and expose express app instance
 * @description This file is responsible for creating instance of express.
 * The app instance along with the express router are exposed to be used by HTTP server.
 * */
const express = require("express");
const bodyParser = require("body-parser");
const router = express.Router();
const app = express();

global.__basedir = __dirname;

app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json({
    extended: true
}));

app.use('/', router);

app.use(function(req,res,next) {
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Methods","GET,POST,PUT,DELETE");
    next();
});

module.exports = {
    app,
    router
}