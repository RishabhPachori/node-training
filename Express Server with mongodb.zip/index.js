/**
 * @file index.js
 * @summary Creates HTTP server
 * @description This file is responsible for creating an HTTP server and adding routes.
 * Server is created by binding express app instance.
 * */
const { createServer } = require("http");
const { constants } = require("./config");
const { log } = require("./errors");
const { app,router} = require("./app");
const { connectToMongoDb } = require("./db");
const initiatesRoutes = require("./modules");


const { PORT , LOG_LEVELS } = constants;

connectToMongoDb();

initiatesRoutes(router);

const server = createServer(app);



// Event Listener for catching uncaught errors
process.on("unhandledRejection", error => {
    log(LOG_LEVELS.ERROR, error.message, {time: new Date() });
    process.exit(1);
});

process.on("uncaughtException", error => {
    log(LOG_LEVELS.ERROR, error.message, {time: new Date()});
    process.exit(1);
});

process.on("exit", code => {
    console.log(`Exiting with the code ${code}`);
});


server.listen(PORT,err => {
    if(err){
       return console.log(`PORT Not Found ${err}`);
    }
    console.log(`Server Listening at ${PORT}`);
});
















/* app.get('/users', function(req,res) {
    console.log("Hello World");
    fs.readFile(__dirname + "/" + "user.json",function(err,data) {
        res.end(data);
    })
})

app.get('/users/:id', function(req,res) {
    fs.readFile(__dirname + "/" + "user.json",function(err,data) {
        users = JSON.parse(data);
        //console.log(req.params.id);
        let user = users["user" + req.params.id];
        res.end(JSON.stringify(user));
    })
}) */


