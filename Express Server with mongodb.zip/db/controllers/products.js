/**
 * @file product.js
 * @summary Define and exposes methods for product entity
 */

const { Products } = require(__basedir + "/db/models");

/**
 * Method for register product in db
 * @param {Object} productObj product info to save
 */
const createProduct = (productObj)=>{
   const product = new Products(productObj);
   return product.save();
};

/**
 * Method for getting product info
 * @param {Object} productData productData info
 */
const getProduct = (productData)=> Products.findOne(productData).lean();

/**
 * Method for get all products
 * @param {object} productData productData info
 */
const getAllProducts = (productData)=> Products.find(productData).lean();

/**
 * Method for update product by Id
 * @param {Object} productId productId
 * @param {Object} updates conatins updated data object
 */
const updateProductById =(productId,updates)=> Products.updateOne({ _id: productId }, { $set: updates });

/**
 * Method for delete product by Id
 * @param {object} productId productId
 */
const deleteProductById =(productId)=> Products.deleteOne({ _id: productId });





module.exports = {
    createProduct,
    getProduct,
    getAllProducts,
    updateProductById,
    deleteProductById
};