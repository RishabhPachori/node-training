/**
 * @file users.js
 * @summary Define and exposes methods for user entity
 */

 const { Users } = require(__basedir + "/db/models");

 /**
  * Method for register user in db
  * @param {Object} userObj user info to save
  */
 const createUser = (userObj)=>{
    const user = new Users(userObj);
    return user.save();
 };

 /**
  * Method for getting user info
  * @param {Object} userData userData 
  */
 const getUser = (userData)=> Users.findOne(userData).lean();
 
/**
 * Method for get all users
 * @param {object} userData userData info
 */

 const getAllUsers = (userData)=> Users.find(userData).lean();

 /**
 * Method for update user by Id
 * @param {Object} userId userId
 * @param {Object} updates conatins updated data object
 */
const updateUserById =(userId,updates)=>  Users.updateOne({ _id: userId }, { $set: updates });

 /**
 * Method for delete user by Id
 * @param {Object} userId userId
 */
const deleteUserById =(userId)=>  Users.deleteOne({ _id: userId });
 



module.exports = {
    createUser,
    getUser,
    getAllUsers,
    updateUserById,
    deleteUserById
 };