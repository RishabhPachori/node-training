const { connectToMongoDb } = require("./connection");

module.exports = {
    connectToMongoDb
};