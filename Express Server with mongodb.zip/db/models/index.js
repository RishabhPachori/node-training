const { Users } = require("./users");
const { Products } = require("./products");

module.exports = {
    Users,
    Products
};