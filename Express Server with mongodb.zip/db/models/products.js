/**
 * @file products.js
 * @summary Define product Schema
 */

const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId, 
        ref: "Users",
        required : true
    },
   productName: {
       type : String,
       required : true
   },
   productDesc: {
       type : String,
       required : true
   }
});

module.exports = {
   Products : mongoose.model("Products",productSchema)
};







