/**
 * @file controller.js
 * @summary product Controllers
 * @description It contains controller definition for product entity
 * Each method is responsible to passing data , extracting data , passing to correspond action
 * and send response back to client. 
 */
const { getProductData,addProductData, updateProductData, deleteProductData } = require("./actions");


/**
 * Controller for get all the products
 * @param {object} req Http req object
 * @param {object} res Http res object
*/
const getProducts = async (req,res) => {
    try {
        const payload = req.user;
        const data = await getProductData(payload);
        return res.status(200).send(data);
    }catch (error) {
        res.status(error.code).send({
            error: error.message
        });
    }
}


/**
 * Controller for add or create products.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const addProduct = async (req,res) => {
    try {
        const payload = req.user;
        const productObj = req.body;
        const data = await addProductData(payload,productObj);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

/**
 * Controller for updates product related information .
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const updateProduct = async (req,res) => {
    try {
        const payload = req.user;
        const productId = req.params.id;
        const updatedData = req.body;
        const data = await updateProductData(payload,productId,updatedData);
        return res.status(200).send(data);
    }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

/**
 * Controller for deletes product related information .
 * @param {object} req Http req object
 * @param {object} res Http res object
 */
const deleteProduct =  async (req,res) => {
    try {
        const payload = req.user;
        const productId = req.params.id;
        const data = await deleteProductData(payload,productId);
        return res.status(200).send(data);
    }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

module.exports ={
    getProducts,
    addProduct,
    updateProduct,
    deleteProduct

};