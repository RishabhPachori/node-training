const { deleteProductData } = require("./deleteProductData");

module.exports = {
    deleteProductData
};