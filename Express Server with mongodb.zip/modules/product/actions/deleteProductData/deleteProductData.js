/**
 * @file deleteProductData.js
 * @summary delete product related information
 */
const { users } = require(__basedir + "/db/controllers");
const { products } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir+"/errors");

/**
 * method for product related information
 * @param {object} payload payload is received when user is authenticated.
 * @param {number} productId product id
 */

const deleteProductData = async (payload,productId)=>{
    const user = await users.getUser({ email:payload.email });
    const product = await products.getProduct({ _id:productId });
    const userId = JSON.stringify(user._id);
    const productUserId = JSON.stringify(product.user);
    if(user.role === "admin"){
        const updateData = await products.deleteProductById(productId);
        return updateData;
    }else if(user.role === "user" && userId === productUserId){
        const updateData = await products.deleteProductById(productId);
        return updateData;
    }else{
        throwBadRequestError("Product not deleted...!!!");
    }

};

module.exports = {
    deleteProductData
};