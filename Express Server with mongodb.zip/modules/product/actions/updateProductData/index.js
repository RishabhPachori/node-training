const { updateProductData } = require("./updateProductData");

module.exports = {
    updateProductData
};