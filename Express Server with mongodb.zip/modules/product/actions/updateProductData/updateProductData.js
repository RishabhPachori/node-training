/**
 * @file updateProductData.js
 * @summary updates product data by Id
 */
const { users } = require(__basedir + "/db/controllers");
const { products } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir+"/errors");

/**
 * Method for updates product data by Id
 * @param {object} payload payload is received when user is authenticated.
 * @param {number} productId product Id
 * @param {object} updatedData updated Data
 */

const updateProductData = async (payload,productId,updatedData)=>{
    const user = await users.getUser({ email:payload.email });
    const product = await products.getProduct({ _id:productId });
    const userId = JSON.stringify(user._id);
    const productUserId = JSON.stringify(product.user);
    if(user.role === "admin"){
        const updateData = await products.updateProductById(productId,updatedData);
        return updateData;
    }else if(user.role === "user" && userId === productUserId){
        const updateData = await products.updateProductById(productId,updatedData);
        return updateData;
    }else{
        throwBadRequestError("Product not updated...!!!");
    }
};

module.exports = {
    updateProductData
};