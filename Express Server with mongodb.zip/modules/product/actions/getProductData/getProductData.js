/**
 * @file getProductData.js
 * @summary get all products related information
 */
const { users } = require(__basedir + "/db/controllers");
const { products } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir+"/errors");

/**
 * Method for get all products
 * @param {object} payload payload is received when user is authenticated.
 */

const getProductData = async (payload) =>{
    const user = await users.getUser({ email:payload.email });
    if(user.role === "admin"){
        const productData = await products.getAllProducts();
        return productData;
    }else if(user.role === "user"){
        const productData = await products.getAllProducts({user:user._id});
        return productData;
    }else{
        throwBadRequestError("User Not Found");
    }
};



module.exports = {
    getProductData
};