const { getProductData } = require("./getProductData");

module.exports = {
    getProductData
};