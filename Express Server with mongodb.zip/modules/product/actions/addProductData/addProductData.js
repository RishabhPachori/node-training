/**
 * @file addProductData.js
 * @summary add product related information
 */
const { users } = require(__basedir + "/db/controllers");
const { products } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir + "/errors");




/**
 * method for create or add product information
 * @param {object} payload payload is received when user is authenticated.
 * @param {object} productObj product Object
 */


const addProductData = async (payload,productObj) =>{
    const user = await users.getUser({ email: payload.email });
    productObj["user"]=user._id;
    if(user.role === "user" || user.role === "admin"){
        const result = await products.createProduct(productObj);
        return {
            result:result,
            message: "Product added successfully...!!"
        };
    }else{
        throwBadRequestError("Product not added..!!");
    }
};


module.exports = {
    addProductData
};