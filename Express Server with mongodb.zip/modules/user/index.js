/**
 * @file index.js
 * @summary File contains User Routes 
 */
const { getUsers,registerUser,updateUser,deleteuser,loginUser } = require("./controller");
const { authenticateUserWithToken } = require(__basedir+"/middlewares");

module.exports = router => {
    router.get("/users",authenticateUserWithToken,getUsers);
    router.post("/register-user",registerUser);
    router.put("/users/:id",authenticateUserWithToken,updateUser);
    router.delete("/users/:id",authenticateUserWithToken,deleteuser);
    router.post("/login-user",loginUser);
};