/**
 * @file deleteUserData.js
 * @summary delete user related information
 */

const { users } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir + "/errors");
/**
 * method for user related information
 * @param {object} payload payload is received when user is authenticated.
 * @param {number} userId user id
 */

const deleteUserData = async (payload,id)=>{
    const user = await users.getUser({ email:payload.email });
    if(user.role === "admin"){
        const updateData = await users.deleteUserById(id);
        return updateData;
    }else if(user.role === "user" && user._id == id){
        const updateData = await users.deleteUserById(id);
        return updateData;
    }else{
        throwBadRequestError("User not deleted...!!!");
    }

};



module.exports = {
    deleteUserData
};