/**
 * @file getUserData.js
 * @summary get all  users related information
 */

const { users } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir+"/errors");


/**
 * Method for get all users by admin
 * @param {Object} payload payload is received when user is authenticated.  
 */


const getUserData = async (payload) =>{
    const user = await users.getUser({ email:payload.email });
    if(user.role === "admin"){
        const userData = await users.getAllUsers();
        return userData;
    }else if(user.role === "user"){
        return user;
    }else{
        throwBadRequestError("User Not Found");
    }
};


module.exports = {
    getUserData
};
