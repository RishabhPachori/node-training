const { getUserData } = require("./getUserData");

module.exports = {
    getUserData
};