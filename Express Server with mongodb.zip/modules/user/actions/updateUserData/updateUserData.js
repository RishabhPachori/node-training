/**
 * @file updateUserData.js
 * @summary updates user data by Id
 */

const { users } = require(__basedir + "/db/controllers");
const bcrypt = require("bcrypt");
const { throwUnAuthorizedError } = require(__basedir + "/errors");


/**
 * Method for updates user data by Id
 * @param {object} payload payload is received when user is authenticated.
 * @param {number} id userId
 * @param {object} updatedData updated Data
 */

const updateUserData = async (payload,id,updatedData)=>{
    updatedData.password = await bcrypt.hash(updatedData.password,10);
    const user = await users.getUser({ email:payload.email });
    if(user.role === "admin"){
        const updateData = await users.updateUserById(id,updatedData);
        return updateData;
    }else if(user.role === "user" && user._id == id){
        const updateData = await users.updateUserById(id,updatedData);
        return updateData;
    }else{
        throwUnAuthorizedError("you are not authorized");
    }

};



module.exports = {
    updateUserData
};



