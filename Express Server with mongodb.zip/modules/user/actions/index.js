const { getUserData } = require("./getUserData");
const { addUserData } = require("./addUserData");
const { updateUserData } = require("./updateUserData");
const { deleteUserData } = require("./deleteUserData");
const { checkUserAuthenticate } = require("./checkUserAuthenticate");

module.exports = {
    getUserData,
    addUserData,
    updateUserData,
    deleteUserData,
    checkUserAuthenticate
};