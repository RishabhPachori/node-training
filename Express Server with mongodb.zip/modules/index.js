/**
 * @file index.js
 * @summary file intiates routes
 */
const user = require("./user");
const product = require("./product");

const initiatesRoutes = router => {
    // all modules with routes will be added here
    user(router);
    product(router);
};

module.exports = initiatesRoutes;
