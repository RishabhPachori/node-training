/**
 * @file logger.js
 * @summary It contains logger definition and configuration.
 * @defintiion file defines to expose a method to log errors on console. 
 */
const { createLogger, format, transports } = require("winston");

const { constants } = require("../config");

const { ENV, ENVIRONMENTS, LOG_LEVELS } = constants;

const logger = createLogger();

if (ENV === ENVIRONMENTS.DEVELOPEMENT){
    logger.add(new transports.Console({
        format: format.simple(),
        level: LOG_LEVELS.INFO
    }));
}

/**
 * Methods to create a log entry which log in our console.  
 * @param {string} level Log level such as DEBUG, INFO, etc
 * @param {string} message  Message to log
 * @param {string} info Extra information to log
 */

const log =(level,message,info)=> {
    logger.log(level,message,info);
};

module.exports = {
    log
};